package com.android.developer.shaliniv.stackecom;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class HomeScreen extends AppCompatActivity {
    ImageView back,add,remove;
    TextView selecteditems,total,txtCount4,txtCount5,txtCount10,txtCount12,txtCount13,txtCount15,txtCount17,txtCount33;
    int count = 0;
    TextView Tprice,Titems,items;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);


        LinearLayout l1 = (LinearLayout) this.findViewById(R.id.laptop);
        LinearLayout l2 = (LinearLayout) this.findViewById(R.id.mobile);
        l1.setVisibility(View.VISIBLE);
        l2.setVisibility(View.GONE);

        TextView lap = (TextView)findViewById(R.id.bl);
        lap.setOnClickListener(v -> {
            l1.setVisibility(View.VISIBLE);
            l2.setVisibility(View.GONE);
        });

        //TextView mob = (TextView)findViewById(R.id.bm);
       // mob.setOnClickListener(v -> {
         //   l2.setVisibility(View.VISIBLE);
           // l1.setVisibility(View.GONE);
        //});

    }
}